import keyboard

# Press key

def ESC():
    keyboard.press('esc')

def ENTER():
    keyboard.press('enter')

def TAB():
    keyboard.press('tab')

def CTRL():
    keyboard.press('ctrl')
    
def SHIFT():
    keyboard.press('shift')

def SUPER():
    keyboard.press('win')

def PAGEUP():
    keyboard.press('pageup')

def PAGEDOWN():
    keyboard.press('pagedown')
    
def END():
    keyboard.press('end')

def HOME():
    keyboard.press('home')

def LEFT():
    keyboard.press('left')

def RIGHT():
    keyboard.press('right')

def UP():
    keyboard.press('up')

def DOWN():
    keyboard.press('down')

def NUM_LOCK():
    keyboard.press('numlock')

def F1():
    keyboard.press('f1')

def F2():
    keyboard.press('f2')

def F3():
    keyboard.press('f3')

def F4():
    keyboard.press('f4')

def F5():
    keyboard.press('f5')

def F6():
    keyboard.press('f6')

def F7():
    keyboard.press('f7')

def F8():
    keyboard.press('f8')

def F9():
    keyboard.press('f9')

def F10():
    keyboard.press('f10')

def F11():
    keyboard.press('f11')

def F12():
    keyboard.press('f12')

def INSERT():
    keyboard.press('insert')

def DEL():
    keyboard.press('delete')

def FN():
    keyboard.press('fn')

def BACKSPACE():
    keyboard.press('backspace')

# Release

def ESC_():
    keyboard.release('esc')

def ENTER_():
    keyboard.release('enter')

def TAB_():
    keyboard.release('tab')

def CTRL_():
    keyboard.release('ctrl')
    
def SHIFT_():
    keyboard.release('shift')

def SUPER_():
    keyboard.release('win')

def PAGEUP_():
    keyboard.release('pageup')

def PAGEDOWN_():
    keyboard.release('pagedown')
    
def END_():
    keyboard.release('end')

def HOME_():
    keyboard.release('home')

def LEFT_():
    keyboard.release('left')

def RIGHT_():
    keyboard.release('right')

def UP_():
    keyboard.release('up')

def DOWN_():
    keyboard.release('down')

def NUM_LOCK_():
    keyboard.release('numlock')

def F1_():
    keyboard.release('f1')

def F2_():
    keyboard.release('f2')

def F3_():
    keyboard.release('f3')

def F4_():
    keyboard.release('f4')

def F5_():
    keyboard.release('f5')

def F6_():
    keyboard.release('f6')

def F7_():
    keyboard.release('f7')

def F8_():
    keyboard.release('f8')

def F9_():
    keyboard.release('f9')

def F10_():
    keyboard.release('f10')

def F11_():
    keyboard.release('f11')

def F12_():
    keyboard.release('f12')

def INSERT_():
    keyboard.release('insert')

def DEL_():
    keyboard.release('delete')

def FN_():
    keyboard.release('fn')

def BACKSPACE_():
    keyboard.release('backspace')
